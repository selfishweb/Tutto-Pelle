jQuery(function($){
	$(document).ready(function(){
		$('.owl-carousel').owlCarousel({
			loop:true,
			items:1,
			nav:true,
			dots: false,
		});
	});
});